def create_histogram(inventory, lebar_max, is_sorted=False):
    sorted_inventory = dict(sorted(inventory.items())) if is_sorted else inventory
    max_quantity = max(sorted_inventory.values())
    histogram = {}
    for item, quantity in sorted_inventory.items():
        normalized_quantity = round((quantity / max_quantity) * lebar_max)
        histogram[item] = '*' * normalized_quantity
    return histogram

def print_histogram(histogram):
    max_item_length = max(len(item) for item in histogram.keys())
    print("=" * (max_item_length + 9))
    print(f" Tabel inventory ")
    print("=" * (max_item_length + 9))
    for item, bars in histogram.items():
        print(f"{item} [{bars.count('*'):02d}]: {bars}")

lebar_max = int(input("lebar_max: "))
is_sorted = input("is_sorted? (y/n): ").lower() == 'y'

inventory = {
    "Lead": 15,
    "Bread": 79,
    "Apple": 22,
    "Bone": 75,
    "Hoe": 1,
    "Pickaxe": 60,
    "Egg": 13,
    "Milk": 17,
    "Slimeball": 94,
    "Salmon": 29,
    "Potato": 45,
    "Gunpowder": 3,
    "Feather": 85,
    "Shears": 95,
    "Wheat": 70,
    "Bucket": 98,
    "Carrot": 26,
    "Crossbow": 23,
    "Arrow": 33,
    "Clay": 23
}

histogram = create_histogram(inventory, lebar_max, is_sorted)
print_histogram(histogram)