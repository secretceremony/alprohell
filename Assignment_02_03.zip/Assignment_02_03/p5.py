inventory = {
  "Emerald": 2,
  "Diamond": 30,
  "Redstone": 11,
  "Brick": 28,
  "Coal": 17,
  "Snowball": 0,
  "Leather": 10,
  "Paper": 9,
  "Flint": 4
}

max_length = max(len(material) for material in inventory.keys())

print("Tabel inventory:")
for material, count in inventory.items():
    stars = "*" * count

    print(f"{material:{max_length}s}: {stars}")
