import string

def is_valid_password(password):
    if 8 <= len(password) <= 16:
        if all(char in string.ascii_letters + string.digits + '_+?' for char in password):
            has_digit = any(char.isdigit() for char in password)
            has_alpha = any(char.isalpha() for char in password)
            has_special = any(char in '_+?' for char in password)

            if has_digit and has_alpha and has_special:
                return True

    return False

password = input("Masukkan password: ")

if is_valid_password(password):
    print("Password valid!")
else:
    print("Password tidak valid. Pastikan memenuhi semua kriteria.")



